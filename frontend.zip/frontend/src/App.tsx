import Controller from "./components/Controller.tsx"

function App() {
  return (
    <>
       <Controller />
    </>
  )
}

export default App
